package com.ncr.inventory;

public class StoreNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StoreNotFoundException(String sku, String store) {
		super("store count not found"+ sku + "'." + store );
	}

}
