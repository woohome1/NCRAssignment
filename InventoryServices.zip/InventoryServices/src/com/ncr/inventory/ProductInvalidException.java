package com.ncr.inventory;

public class ProductInvalidException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
