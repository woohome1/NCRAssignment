package com.ncr.inventory;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="product")
public class ProdMessage {
	    @XmlElement(name="sku") String sku;
	    @XmlElement(name="pName") String pName;
	    
	    @XmlElement(name="store") String store;
	    @XmlElement(name="count") int count;
	    
	    
	     
}
