package com.ncr.inventory;

public class UpdateStoreCountFailException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UpdateStoreCountFailException(String sku, String store, int count) {
		super("Product Store update failed" + sku + "'." +  store + "'."+  count + "'.");
	}

}
