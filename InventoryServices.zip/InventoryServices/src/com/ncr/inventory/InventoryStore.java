package com.ncr.inventory;


import java.util.HashMap;
import java.util.Map;

public class InventoryStore {
	private final static Map<String,Product> store = new HashMap<String,Product>() ;
	
	
	private static Map<String,Product> getStore() {
		
		return InventoryStore.store;
	}
	
	public void registerProd (Product p) throws  ProductExistException   {
		String sku = p.getSku();
		try {
			if (!getStore().containsKey(sku)) 
				
				getStore().put(sku,p) ;
			else
				throw (new ProductExistException(sku));
		}
		catch (ProductExistException e) {
			throw (e);
		}
		catch (Exception e) {
			throw (new ProductRegisterFailException());
		}
	}
	
	public void updateStoreCount(Product p, String store, int count) throws ProductNotRegisteredException, UpdateStoreCountFailException{
		String sku = p.getSku();
		try {
			
			if ( !getStore().containsKey(sku)) 
			 
				throw (new ProductNotRegisteredException(sku));
			else {
				// if new update does not provide product name, keep the existing product name
				// if new update provide product name, use it as the new product name
				if (p.getProductName().trim().length() == 0)
					getStore().get(sku).getStoreCount().put(store, count);
				else {
					getStore().put(sku, p);
					getStore().get(sku).getStoreCount().put(store, count);
					
				}
			}
				
		}
		catch (ProductNotRegisteredException e) {
			throw (e);
		}
		catch (Exception e) {
				throw (new UpdateStoreCountFailException(sku, store, count));
		}
	}
	
	public int getProdCountByStore(String sku, String store) throws ProductNotRegisteredException,StoreNotFoundException  {
		Product p = null;
		if ((p = getStore().get(sku)) == null )
			throw (new ProductNotRegisteredException(sku));
		if ( p.getStoreCount().get(store) == null )
			throw ( new StoreNotFoundException(sku, store));
		
		return getStore().get(sku).getStoreCount().get(store);
	}
	
	public String getProdName(String sku )  throws  ProductNotRegisteredException {
		Product p = null;
		if ((p = getStore().get(sku)) == null )
			throw (new ProductNotRegisteredException(sku));
	    return (p.getProductName());
		
		 
	}
	
}
