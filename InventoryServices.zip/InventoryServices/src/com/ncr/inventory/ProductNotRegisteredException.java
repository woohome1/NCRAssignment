package com.ncr.inventory;

public class ProductNotRegisteredException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ProductNotRegisteredException(String sku) {
		super("Product not yet registered" + sku + "'.");
	}

}
