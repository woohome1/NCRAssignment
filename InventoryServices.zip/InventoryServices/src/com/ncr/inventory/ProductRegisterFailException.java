package com.ncr.inventory;

public class ProductRegisterFailException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
