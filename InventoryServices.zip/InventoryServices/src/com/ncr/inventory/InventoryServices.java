package com.ncr.inventory;
 
 
import javax.ws.rs.Consumes;
 
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
 
import javax.ws.rs.core.MediaType;
 
import javax.ws.rs.core.Response;
 

@Path("/InventoryService") 
public class InventoryServices {
	

	@POST
	@Path("/products")
	@Consumes(MediaType.APPLICATION_XML)
	public Response registerProduct(ProdMessage request ) {
		
		Product p = new Product(request.sku,request.pName );
		if (!p.isValid())
			return(Response.status(422).build());
		InventoryStore inv = new InventoryStore();
		try {
		inv.registerProd( p);
		return(Response.status(201).build());
		}
		catch (ProductExistException e) {
			 
			return(Response.status(409).build());
		}
		catch (ProductRegisterFailException e) {
			 
			return (Response.status(500).build());
		}
		 
	}
	
	
	   @PUT
	   @Path("/products")
	   @Consumes(MediaType.APPLICATION_XML)
	   public Response updateProduct(ProdMessage request) {
		    Product p = new Product(request.sku, request.pName );
			InventoryStore inv = new InventoryStore();
			try {
			inv.updateStoreCount( p, request.store, request.count);
			return(Response.ok().build());
			}
			catch (ProductNotRegisteredException e) {
				return(Response.status(404).build());
			}
			catch (UpdateStoreCountFailException e) {
				return (Response.status(500).build());
			} 
	   }
	   
	   @GET
	   @Path("/products/{sku}/{store}")
	   @Consumes(MediaType.APPLICATION_XML)
	   @Produces(MediaType.APPLICATION_XML)
	   public Response getProdCountByStore(@PathParam("sku") String sku , @PathParam("store") String store){
		   InventoryStore inv = new InventoryStore();
		   
		   try {
			   
		   int count = inv.getProdCountByStore(sku, store);
		   String pname = inv.getProdName(sku);
		   ProdMessage p = new ProdMessage ();
		   p.count = count;
		   p.pName = pname;
		   p.sku = sku;
		   p.store  = store;
		   
		   return(Response.ok(p)).build();
 
		   } 
		   catch ( ProductNotRegisteredException e) {
			   return( Response.status(404).build());
		   }
		   catch (  StoreNotFoundException e) {
			  return ( Response.status(404).build() );
		   }
		   
	   }

	

}
