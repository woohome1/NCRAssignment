package com.ncr.inventory;

import java.util.Map;
import java.util.HashMap;



public class Product {
	private String productName=null;
	private String sku = null;
	
	private Map <String, Integer>storeCount=null;
	
	Product (String sku, String prodName){
		this.setSku (sku);
		this.setProductName(prodName);
		setStoreCount(new HashMap<String,Integer>());
	}

	

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Map <String, Integer> getStoreCount() {
		return storeCount;
	}

	public void setStoreCount(Map <String, Integer> storeCount) {
		this.storeCount = storeCount;
	}

	public String getSku() {
		return sku;
	}
	

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public boolean isValid() {
		// name and sku can not be blank
		return ( this.getProductName().trim().length() > 0 &&  this.getSku().trim().length() > 0 );
	}
}
