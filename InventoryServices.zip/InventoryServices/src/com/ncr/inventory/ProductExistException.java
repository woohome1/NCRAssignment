package com.ncr.inventory;

public class ProductExistException extends RuntimeException {
	 
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		/**
	 * 
	 */
	 

		public ProductExistException(String prodId) {
			super("Product Already Exist" + prodId + "'.");
		}

	 

}
